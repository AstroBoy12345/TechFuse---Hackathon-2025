package org.tv.unitodo.helpers;

public interface ElemType {
    String BUTTON = "button";
    String INPUT = "input";
    String TEXT = "p";
    String HEADER = "h1";
    String WILD_CARD = "*";
}
