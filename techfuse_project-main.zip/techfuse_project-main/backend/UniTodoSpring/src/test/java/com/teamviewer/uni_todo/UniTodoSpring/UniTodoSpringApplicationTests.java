package com.teamviewer.uni_todo.UniTodoSpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UniTodoSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
