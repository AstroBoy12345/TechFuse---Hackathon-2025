import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import { useState, useEffect } from "react";
import HomePage from "./components/HomePage";
import LoginPage from "./components/LoginPage";
import SignUpPage from "./components/SignUpPage";
import ProtectedRoute from "./components/ProtectedRoute";
import DashboardPage from "./components/DashboardPage";
import AdminDashboard from "./components/AdminDashboard";
import AboutPage from "./components/AboutPage";
import ServicesPage from "./components/ServicePage";
import ContactPage from "./components/ContactPage";
import React from 'react';

import AdminAbout from "./components/AdminAbout";
import AdminContact from "./components/AdminContact";
import AdminService from "./components/AdminService";
import Area1Page from "./components/Area1Page";
import Area2Page from "./components/Area2Page";

//import Area1-1MapPage from "./components/Area1-1MapPage";
import ParkingMap from "./components/ParkingMap";


function App() {
    const [userRole, setUserRole] = useState<string | null>(null);
    const [loading, setLoading] = useState<boolean>(true);

    useEffect(() => {
        const fetchUserRole = async () => {
            try {
                const response = await fetch("http://localhost:7046/api/auth/me", {
                    method: "GET",
                    credentials: "include",
                });

                if (response.ok) {
                    const data = await response.json();
                    setUserRole(data.role);
                } else {
                    setUserRole(null);
                }
            } catch (error) {
                console.error("Error fetching user role:", error);
                setUserRole(null);
            } finally {
                setLoading(false);
            }
        };

        fetchUserRole();
    }, []);

    return (
        <Router>
            <Routes>
                {/* Δημόσιες σελίδες */}
                <Route path="/" element={<HomePage />} />
                <Route path="/login" element={<LoginPage updateUserRole={setUserRole} />} />
                <Route path="/signup" element={<SignUpPage />} />

                {/* Προστατευμένες σελίδες για Users και Admins */}
                <Route element={<ProtectedRoute userRole={userRole} allowedRoles={["USER", "ADMIN"]} loading={loading} />}>
                    <Route path="/dashboard" element={<DashboardPage />} />
                    <Route path="/about" element={<AboutPage />} />
                    <Route path="/services" element={<ServicesPage />} />
                    <Route path="/contact" element={<ContactPage />} />
                    <Route path="/area1" element={<Area1Page />} /> {/* ✅ ΝΕΟ */}
                    <Route path="/area2" element={<Area2Page />} /> {/* ✅ ΝΕΟ */}
                    <Route path="/mapTest" element={<ParkingMap />} /> {/* ✅ ΝΕΟ */}
                </Route>

                {/* Προστατευμένες σελίδες για Admins */}
                <Route element={<ProtectedRoute userRole={userRole} allowedRoles={["ADMIN"]} loading={loading} />}>
                    <Route path="/admin-dashboard" element={<AdminDashboard />} />
                    <Route path="/admin-about" element={<AdminAbout />} />
                    <Route path="/admin-services" element={<AdminService />} />
                    <Route path="/admin-contact" element={<AdminContact />} />
                </Route>
            </Routes>
        </Router>
    );
}

export default App;
