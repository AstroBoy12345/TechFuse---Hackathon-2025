import React, { useState } from "react";

const ParkingSelectionWindow: React.FC = () => {
  // Αρχικά όλες οι 5 θέσεις είναι ελεύθερες
  const [occupied, setOccupied] = useState<boolean[]>([false, false, false, false, false]);
  // Αποθηκεύουμε ποια θέση είναι επιλεγμένη (index ή null)
  const [selected, setSelected] = useState<number | null>(null);

  // Πίνακας με τα URLs των εικόνων (αν βρίσκονται απευθείας στο public, το path είναι /p1.png κλπ.)
  const images = ["/p1.png", "/p2.png", "/p3.png", "/p4.png", "/p5.png"];

  // Όταν ο χρήστης πατήσει πάνω σε μία θέση, την επιλέγει (μόνο μία μπορεί να είναι επιλεγμένη κάθε φορά)
  const handleSelect = (index: number) => {
    setSelected(index);
  };

  // Κουμπί "Παρκάρε": σημαδεύει την επιλεγμένη θέση ως κατειλημμένη (αν δεν είναι ήδη)
  const handlePark = () => {
    if (selected !== null && !occupied[selected]) {
      setOccupied(prev => {
        const updated = [...prev];
        updated[selected] = true;
        return updated;
      });
    }
  };

  // Κουμπί "Ξεπαρκάρε": απελευθερώνει την επιλεγμένη θέση, αν είναι κατειλημμένη
  const handleUnpark = () => {
    if (selected !== null && occupied[selected]) {
      setOccupied(prev => {
        const updated = [...prev];
        updated[selected] = false;
        return updated;
      });
    }
  };

  const containerStyle: React.CSSProperties = {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    marginTop: "1.5rem",
  };

  const spotsContainerStyle: React.CSSProperties = {
    display: "flex",
    justifyContent: "center",
    gap: "1rem",
    flexWrap: "wrap",
    marginBottom: "1rem",
  };

  // Μεγαλύτερες εικόνες για τις θέσεις (π.χ. 200x200 pixels)
  const spotStyle: React.CSSProperties = {
    width: "400px",
    height: "400px",
    cursor: "pointer",
    border: "4px solid",
    borderRadius: "8px",
    objectFit: "cover",
  };

  const buttonContainerStyle: React.CSSProperties = {
    display: "flex",
    gap: "1rem",
  };

  const actionButtonStyle: React.CSSProperties = {
    padding: "0.75rem 1.5rem",
    border: "none",
    borderRadius: "4px",
    fontSize: "1rem",
    cursor: "pointer",
  };

  return (
    <div style={containerStyle}>
      <h3 style={{ marginBottom: "0.5rem", color: "#fff" }}>
        Επιλέξτε θέση παρκαρίσματος:
      </h3>
      <div style={spotsContainerStyle}>
        {images.map((img, index) => {
          // Αν η θέση είναι επιλεγμένη, borderColor είναι μπλε, διαφορετικά αν κατειλημμένη είναι κόκκινο, αλλιώς πράσινο.
          let borderColor = selected === index ? "blue" : occupied[index] ? "red" : "green";
          return (
            <img
              key={index}
              src={img}
              alt={`Θέση ${index + 1}`}
              style={{
                ...spotStyle,
                borderColor,
                opacity: occupied[index] ? 0.6 : 1,
              }}
              onClick={() => handleSelect(index)}
            />
          );
        })}
      </div>
      <div style={buttonContainerStyle}>
        <button
          onClick={handlePark}
          style={{ ...actionButtonStyle, backgroundColor: "#00B0FF", color: "#fff" }}
        >
          Παρκάρε
        </button>
        <button
          onClick={handleUnpark}
          style={{ ...actionButtonStyle, backgroundColor: "#FF4444", color: "#fff" }}
        >
          Ξεπαρκάρε
        </button>
      </div>
    </div>
  );
};

export default ParkingSelectionWindow;
