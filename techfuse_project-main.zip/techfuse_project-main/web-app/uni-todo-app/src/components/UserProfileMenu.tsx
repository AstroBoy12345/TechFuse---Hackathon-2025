import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import Avatar from "./Avatar";
import { LogOut, Settings, User } from "lucide-react";

const UserProfileMenu = () => {
  const [open, setOpen] = useState(false);
  const [user, setUser] = useState({ name: "", email: "", avatar: "" });

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const response = await fetch("http://localhost:7046/api/auth/me", {
          method: "GET",
          credentials: "include",
        });
        if (response.ok) {
          const data = await response.json();
          setUser({
            name: data.name,
            email: data.email,
            avatar: data.avatar || "https://randomuser.me/api/portraits/men/1.jpg",
          });
        } else {
          console.error("Failed to fetch user data");
        }
      } catch (error) {
        console.error("Error fetching user data:", error);
      }
    };

    fetchUserData();
  }, []);

  return (
    <div className="relative">
      <button onClick={() => setOpen(!open)} className="flex items-center gap-2 p-2 rounded-lg hover:bg-gray-100 transition">
        <Avatar src={user.avatar} alt="User Avatar" className="w-10 h-10 rounded-full" />
      </button>
      {open && (
        <div className="absolute right-0 mt-2 w-48 bg-white shadow-lg rounded-lg py-2">
          <div className="px-4 py-2 border-b">
            <p className="font-semibold">{user.name}</p>
            <p className="text-sm text-gray-500">{user.email}</p>
          </div>
          <Link to="/profile" className="flex items-center gap-2 px-4 py-2 hover:bg-gray-100">
            <User size={16} /> Profile
          </Link>
        </div>
      )}
    </div>
  );
};

export default UserProfileMenu;