import { useState, useEffect } from "react";
import Avatar from "./Avatar";
import { Link, useNavigate } from "react-router-dom";



const Profile= () => {
  const [open, setOpen] = useState(false);
  const [user, setUser] = useState({ name: "", email: "", avatar: "" });
  const navigate = useNavigate();

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const response = await fetch("http://localhost:7046/api/me", {
          method: "GET",
          credentials: "include",
        });
        if (response.ok) {
          const data = await response.json();
          setUser({
            name: data.name,
            email: data.email,
            avatar: data.avatar || "https://randomuser.me/api/portraits/men/1.jpg",
          });
        } else {
          console.error("Failed to fetch user data");
        }
      } catch (error) {
        console.error("Error fetching user data:", error);
      }
    };

    fetchUserData();
  }, []);

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const response = await fetch("http://localhost:7046/api/user", {
          method: "GET",
          credentials: "include",
          headers: {
            "Content-Type": "application/json",
          },
        });

        if (!response.ok) {
          console.error("Failed to fetch user data");
          return;
        }

        const data = await response.json();
        setUser({
          name: data.name || "Unknown User",
          email: data.email || "No Email",
          avatar: data.avatar || "https://randomuser.me/api/portraits/men/1.jpg",
        });
      } catch (error) {
        console.error("Error fetching user data:", error);
      }
    };

    fetchUserData();
  }, []);

  const handleLogout = async () => {
      try {
        const response = await fetch("http://localhost:7046/api/auth/logout", {
          method: "POST",
          credentials: "include",
        });

        if (response.ok) {
          navigate("/");
        } else {
          console.error("Logout failed.");
        }
      } catch (error) {
        console.error("Error during logout:", error);
      }
    };

  // Styles
    const containerStyle: React.CSSProperties = {
      position: "relative",
      width: "100%",
      height: "100vh",
      overflow: "hidden",
      margin: 0,
      padding: 0,
      fontFamily: "sans-serif",
    };

    const backgroundStyle: React.CSSProperties = {
      position: "absolute",
      top: 0,
      left: 0,
      width: "100%",
      height: "100%",
      backgroundImage: `url("https://images-ext-1.discordapp.net/external/3y6aXITKlbdzzA78bFGisPdxLGbN_n9jlkgm6Jmg7mo/https/www.gtp.gr/MGfiles/location/image29873%5B8707%5D.JPG?format=webp&width=1043&height=695")`,
      backgroundSize: "cover",
      backgroundPosition: "center",
      filter: "blur(8px)",
      zIndex: 1,
    };

    const overlayStyle: React.CSSProperties = {
      position: "absolute",
      top: 0,
      left: 0,
      width: "100%",
      height: "100%",
      backgroundColor: "rgba(0, 0, 0, 0.4)",
      zIndex: 2,
    };

    const contentStyle: React.CSSProperties = {
      position: "relative",
      zIndex: 3,
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      height: "100%",
      color: "#fff",
    };

    const navStyle: React.CSSProperties = {
      width: "100%",
          backgroundColor: "rgba(0, 0, 0, 0.7)",
          padding: "1rem",
          position: "absolute",
          top: 0,
          left: 0,
          zIndex: 4,
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
    };

    const buttonStyle: React.CSSProperties = {
      backgroundColor: "#00B0FF",
      color: "#fff",
      padding: "0.75rem 1.5rem",
      border: "none",
      borderRadius: "4px",
      fontSize: "1rem",
      cursor: "pointer",
    };


  return (
    <div style={containerStyle}>
          <div style={backgroundStyle}></div>
          <div style={overlayStyle}></div>

          <div style={contentStyle}>
            <div className="max-w-md mx-auto bg-white shadow-lg rounded-lg overflow-hidden p-6">
              <div className="flex flex-col items-center">
                <Avatar
                  src={user.avatar}
                  alt="User Avatar"
                  className="w-24 h-24 rounded-full border"
                />
                <h2 className="mt-4 text-xl font-semibold">{user.name}</h2>
                <p className="text-gray-600">{user.email}</p>
              </div>

              <div className="mt-6 text-center">
                <button style={buttonStyle} className="px-4 py-2 rounded-md hover:bg-blue-600 transition">
                  Edit Profile
                </button>
              </div>
            </div>
          </div>

            <nav style={navStyle}>
                              <div className="flex space-x-6">
                                <Link to="/dashboard" className="text-white hover:text-blue-400">
                                  Home
                                </Link>
                                <Link to="/about" className="text-white hover:text-blue-400">
                                  About
                                </Link>
                                <Link to="/services" className="text-white hover:text-blue-400">
                                  Services
                                </Link>
                                <Link to="/contact" className="text-white hover:text-blue-400">
                                  Contact
                                </Link>
                              </div>
                              <button onClick={handleLogout} style={buttonStyle}>
                                Logout
                              </button>

            </nav>
    </div>
  );
};


export default Profile;