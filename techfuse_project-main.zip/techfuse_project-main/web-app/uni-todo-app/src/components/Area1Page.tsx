import React from "react";
import { Link, useNavigate } from "react-router-dom";
//import ParkingSelectionWindow from "./ParkingSelectionWindow";

const Area1Page: React.FC = () => {
    const navigate = useNavigate();

      const handleLogout = async () => {
        try {
          const response = await fetch("http://localhost:7046/api/auth/logout", {
            method: "POST",
            credentials: "include",
          });
          if (response.ok) {
            navigate("/");
          } else {
            console.error("Logout failed.");
          }
        } catch (error) {
          console.error("Error during logout:", error);
        }
      };

      // Κοινά στυλ (ίδια με το DashboardPage)
      const containerStyle: React.CSSProperties = {
        position: "relative",
        width: "100%",
        height: "100vh",
        overflow: "hidden",
        margin: 0,
        padding: 0,
        fontFamily: "sans-serif",
      };

      const backgroundStyle: React.CSSProperties = {
        position: "absolute",
        top: 0,
        left: 0,
        width: "100%",
        height: "100%",
        backgroundImage: `url("https://images-ext-1.discordapp.net/external/3y6aXITKlbdzzA78bFGisPdxLGbN_n9jlkgm6Jmg7mo/https/www.gtp.gr/MGfiles/location/image29873%5B8707%5D.JPG?format=webp&width=1043&height=695")`,
        backgroundSize: "cover",
        backgroundPosition: "center",
        filter: "blur(8px)",
        zIndex: 1,
      };

      const overlayStyle: React.CSSProperties = {
        position: "absolute",
        top: 0,
        left: 0,
        width: "100%",
        height: "100%",
        backgroundColor: "rgba(0, 0, 0, 0.4)",
        zIndex: 2,
      };

      const navStyle: React.CSSProperties = {
        width: "100%",
        backgroundColor: "rgba(0, 0, 0, 0.7)",
        padding: "1rem",
        position: "absolute",
        top: 0,
        left: 0,
        zIndex: 4,
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
      };

      const backButtonStyle: React.CSSProperties = {
            position: "absolute",
            top: "100px",
            left: "20px",
            background: "rgba(0, 0, 0, 0.6)", // Semi-transparent black
            border: "none",
            color: "#fff",
            fontSize: "1rem",
            fontWeight: "bold",
            cursor: "pointer",
            zIndex: 10,
            padding: "10px 15px",
            borderRadius: "50px", // Round shape
            display: "flex",
            alignItems: "center",
            gap: "8px",
            transition: "background 0.2s ease-in-out",
        };

      const buttonStyle: React.CSSProperties = {
        backgroundColor: "#00B0FF",
        color: "#fff",
        padding: "0.75rem 1.5rem",
        border: "none",
        borderRadius: "4px",
        fontSize: "1rem",
        cursor: "pointer",
      };

      const linkStyle: React.CSSProperties = {
        color: "#fff",
        textDecoration: "none",
        fontWeight: 500,
      };

      const contentStyle: React.CSSProperties = {
        position: "relative",
        zIndex: 3,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        height: "100%",
        color: "#fff",
      };

      const imageContainerStyle: React.CSSProperties = {
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        gap: "2rem",
        marginTop: "2rem",
      };

      const imageCardStyle: React.CSSProperties = {
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        cursor: "pointer",
        backgroundColor: "rgba(255, 255, 255, 0.8)",
        borderRadius: "8px",
        padding: "1rem",
        boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)",
      };

      const imageStyle: React.CSSProperties = {
        width: "250px",
        height: "150px",
        borderRadius: "8px",
        objectFit: "cover",
      };

      const textStyle: React.CSSProperties = {
        marginTop: "1rem",
        fontSize: "1.2rem",
        fontWeight: "bold",
        color: "#000",
      };

      return (
        <div style={containerStyle}>
          <div style={backgroundStyle}></div>
          <div style={overlayStyle}></div>

          {/* Navigation bar */}
          <nav style={navStyle}>
            <div className="flex space-x-6">
              <Link to="/dashboard" style={linkStyle}>
                Home
              </Link>
              <Link to="/about" style={linkStyle}>
                Parking
              </Link>
              <Link to="/services" style={linkStyle}>
                Services
              </Link>
              <Link to="/contact" style={linkStyle}>
                Contact
              </Link>
            </div>
            <button onClick={handleLogout} style={buttonStyle}>
              Logout
            </button>
          </nav>


            {/* Back Button */} ------------------

            <button onClick={() => navigate("/about")} style={backButtonStyle}
            onMouseEnter={(e) => (e.currentTarget.style.background = "rgba(0, 0, 0, 0.8)")}
            onMouseLeave={(e) => (e.currentTarget.style.background = "rgba(0, 0, 0, 0.6)")}
                >
                &#8592; Back
            </button>

          {/* Κεντρικό περιεχόμενο */}
          <div style={contentStyle}>
            <h2 style={{ fontSize: "2rem", marginBottom: "1rem" }}>Περιοχή 1</h2>
            <p>Επιλέξτε την ζώνη που θέλετε να παρκάρετε.</p>

            {/* Περιοχές με εικόνες */}
            <div style={imageContainerStyle}>
              {/* Περιοχή 1 */}
              <div style={imageCardStyle} onClick={() => navigate("/mapTest")}>
                <img
                  src="/Perioxh1-1.png"
                  alt="Ζώνη 1"
                  style={imageStyle}
                />
                <span style={textStyle}>Περιοχή 1</span>
              </div>

              {/* Περιοχή 2 */}
              <div style={imageCardStyle} onClick={() => navigate("/area2")}>
                <img
                  src="/Perioxh1-2.png"
                  alt="Ζώνη 2"
                  style={imageStyle}
                />
                <span style={textStyle}>Περιοχή 2</span>
              </div>
            </div>
          </div>
        </div>
      );
    };

export default Area1Page;
