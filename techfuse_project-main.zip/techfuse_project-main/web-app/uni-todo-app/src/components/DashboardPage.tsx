import React from "react";
import {NavBar} from "./NavBar";

const DashboardPage: React.FC = () => {

  // Styles
  const containerStyle: React.CSSProperties = {
    position: "relative",
    width: "100%",
    height: "100vh",
    overflow: "hidden",
    margin: 0,
    padding: 0,
    fontFamily: "sans-serif",
  };

  const backgroundStyle: React.CSSProperties = {
    position: "absolute",
    top: 0,
    left: 0,
    width: "100%",
    height: "100%",
    backgroundImage: `url("https://images-ext-1.discordapp.net/external/3y6aXITKlbdzzA78bFGisPdxLGbN_n9jlkgm6Jmg7mo/https/www.gtp.gr/MGfiles/location/image29873%5B8707%5D.JPG?format=webp&width=1043&height=695")`,
    backgroundSize: "cover",
    backgroundPosition: "center",
    filter: "blur(8px)",
    zIndex: 1,
  };

  const overlayStyle: React.CSSProperties = {
    position: "absolute",
    top: 0,
    left: 0,
    width: "100%",
    height: "100%",
    backgroundColor: "rgba(0, 0, 0, 0.4)",
    zIndex: 2,
  };

  const contentStyle: React.CSSProperties = {
    position: "relative",
    zIndex: 3,
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    height: "100%",
    color: "#fff",
  };




  return (
    <div style={containerStyle}>
      <div style={backgroundStyle}></div>
      <div style={overlayStyle}></div>

      <NavBar isLoggedIn></NavBar>

      {/* Περιεχόμενο της σελίδας */}
      <div style={contentStyle}>
        <h2 style={{ fontSize: "2rem", marginBottom: "1rem" }}>
          Καλώς ήρθατε στο Dashboard σας!
        </h2>
        <p>Εδώ μπορείτε να διαχειριστείτε τις λειτουργίες του λογαριασμού σας.</p>
      </div>
    </div>
  );
};

export default DashboardPage;
