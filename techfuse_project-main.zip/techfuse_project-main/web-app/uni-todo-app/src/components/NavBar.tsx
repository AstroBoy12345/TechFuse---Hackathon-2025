import { Link, useNavigate } from "react-router-dom";
import UserProfileMenu from "./UserProfileMenu";
import React from "react";

const navStyle: React.CSSProperties = {
  width: "100%",
  backgroundColor: "rgba(0, 0, 0, 0.7)",
  padding: "1rem",
  position: "absolute",
  top: 0,
  left: 0,
  zIndex: 4,
  display: "flex",
  flexWrap: "wrap",
  justifyContent: "space-between",
  alignItems: "center",
};

const linkContainerStyle: React.CSSProperties = {
  display: "flex",
  flexWrap: "wrap",
  gap: "1rem",
};

const buttonStyle: React.CSSProperties = {
  backgroundColor: "#00B0FF",
  color: "#fff",
  padding: "0.4rem 1.0rem",
  border: "none",
  borderRadius: "4px",
  fontSize: "1rem",
  cursor: "pointer",
};

export const NavBar: React.FC<{ isLoggedIn: boolean }> = ({ isLoggedIn }) => {
  const navigate = useNavigate();

  const handleLogout = async () => {
    try {
      const response = await fetch("http://localhost:7046/api/auth/logout", {
        method: "POST",
        credentials: "include",
      });

      if (response.ok) {
        navigate("/");
      } else {
        console.error("Logout failed.");
      }
    } catch (error) {
      console.error("Error during logout:", error);
    }
  };

  return (
    <nav style={navStyle}>
      <div style={linkContainerStyle}>
        <Link to="/dashboard" style={{ ...linkStyle }} onMouseOver={(e) => (e.currentTarget.style.color = "blue")} onMouseOut={(e) => (e.currentTarget.style.color = "white")}>
          Home
        </Link>
        <Link to="/about" style={{ ...linkStyle }} onMouseOver={(e) => (e.currentTarget.style.color = "blue")} onMouseOut={(e) => (e.currentTarget.style.color = "white")}>
          Parking
        </Link>
        <Link to="/services" style={{ ...linkStyle }} onMouseOver={(e) => (e.currentTarget.style.color = "blue")} onMouseOut={(e) => (e.currentTarget.style.color = "white")}>
          Services
        </Link>
        <Link to="/contact" style={{ ...linkStyle }} onMouseOver={(e) => (e.currentTarget.style.color = "blue")} onMouseOut={(e) => (e.currentTarget.style.color = "white")}>
          Contact
        </Link>
        {!isLoggedIn && (
            <>
            <Link to="/login"  style={{ ...linkStyle }} onMouseOver={(e) => (e.currentTarget.style.color = "blue")} onMouseOut={(e) => (e.currentTarget.style.color = "white")}>Login</Link>
            <Link to="/signup" style={{ ...linkStyle }} onMouseOver={(e) => (e.currentTarget.style.color = "blue")} onMouseOut={(e) => (e.currentTarget.style.color = "white")}>SignUp</Link>
            </> 
        )}
      </div>
      {isLoggedIn && (
        <div className="flex items-center gap-4">
          <UserProfileMenu />
          <button onClick={handleLogout} style={buttonStyle}>
            Logout
          </button>
        </div>
      )}
    </nav>
  );
};

const linkStyle: React.CSSProperties = {
  color: "white",
  textDecoration: "none",
  transition: "color 0.3s",
};