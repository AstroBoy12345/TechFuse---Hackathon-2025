import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";

// Ορισμός του τύπου για το state isAuthenticated
type AuthState = boolean | null;

const HomePage: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState<AuthState>(null);
  const navigate = useNavigate();


  // Στυλ για το background & layout
  const containerStyle: React.CSSProperties = {
    position: "relative",
    width: "100%",
    height: "100vh",
    overflow: "hidden",
    margin: 0,
    padding: 0,
    fontFamily: "sans-serif",
  };

  const backgroundStyle: React.CSSProperties = {
    position: "absolute",
    top: 0,
    left: 0,
    width: "100%",
    height: "100%",
    // Η ίδια εικόνα με το Dashboard/Login
    backgroundImage: `url("https://images-ext-1.discordapp.net/external/3y6aXITKlbdzzA78bFGisPdxLGbN_n9jlkgm6Jmg7mo/https/www.gtp.gr/MGfiles/location/image29873%5B8707%5D.JPG?format=webp&width=1043&height=695")`,
    backgroundSize: "cover",
    backgroundPosition: "center",
    filter: "blur(8px)", // Θολώνει το background για καλύτερη αναγνωσιμότητα
    zIndex: 1,
  };

  const overlayStyle: React.CSSProperties = {
    position: "absolute",
    top: 0,
    left: 0,
    width: "100%",
    height: "100%",
    backgroundColor: "rgba(0, 0, 0, 0.4)", // Ημιδιαφανές overlay
    zIndex: 2,
  };

  const navStyle: React.CSSProperties = {
    width: "100%",
    backgroundColor: "rgba(0, 0, 0, 0.7)",
    padding: "1rem",
    position: "absolute",
    top: 0,
    left: 0,
    zIndex: 4,
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
  };

  // Δύο container για τα αριστερά και δεξιά links
  const linkContainerStyle: React.CSSProperties = {
    display: "flex",
    gap: "1rem",
  };

  const linkStyle: React.CSSProperties = {
    color: "#fff",
    textDecoration: "none",
    fontWeight: 500,
  };

  const contentStyle: React.CSSProperties = {
    position: "relative",
    zIndex: 3,
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    height: "100%",
    color: "#fff",
  };

  return (
    <div style={containerStyle}>
      <div style={backgroundStyle}></div>
      <div style={overlayStyle}></div>

      {/* Navigation bar */}
      <nav style={navStyle}>
        <div style={linkContainerStyle}>
          <Link to="/" style={linkStyle}>Home</Link>
          <Link to="/login" style={linkStyle}>Parking</Link>
          <Link to="/login" style={linkStyle}>Services</Link>
          <Link to="/login" style={linkStyle}>Contact</Link>
        </div>
        <div style={linkContainerStyle}>
          <Link to="/login" style={linkStyle}>Login</Link>
          <Link to="/signup" style={linkStyle}>SignUp</Link>
        </div>
      </nav>

      {/* Περιεχόμενο της σελίδας */}
      <div style={contentStyle}>
        <h1 style={{ fontSize: "2rem", marginBottom: "1rem" }}>
          Welcome to ByteForce!
        </h1>
        <p>Explore our services and feel free to contact us.</p>
      </div>
    </div>
  );
};

export default HomePage;
