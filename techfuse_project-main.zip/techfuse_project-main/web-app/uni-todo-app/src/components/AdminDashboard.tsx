import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

const AdminDashboard: React.FC = () => {
  const [message, setMessage] = useState<string>("");
  const navigate = useNavigate();

  const handleClearDatabase = async () => {
    try {
      const response = await fetch("http://localhost:7046/api/admin/clear-database", {
        method: "DELETE",
        credentials: "include",
      });

      if (response.ok) {
        setMessage("✅ Η βάση δεδομένων αδειάστηκε επιτυχώς!");
      } else {
        setMessage("❌ Αποτυχία αδειάσματος της βάσης δεδομένων.");
      }
    } catch (error) {
      console.error("Σφάλμα κατά το άδειασμα της βάσης:", error);
      setMessage("⚠ Παρουσιάστηκε σφάλμα κατά το άδειασμα της βάσης.");
    }
  };

  const handleLogout = async () => {
    try {
      const response = await fetch("http://localhost:7046/api/auth/logout", {
        method: "POST",
        credentials: "include",
      });

      if (response.ok) {
        navigate("/");
      } else {
        console.error("Logout failed.");
      }
    } catch (error) {
      console.error("Error during logout:", error);
    }
  };

  // Styles
  const containerStyle: React.CSSProperties = {
    position: "relative",
    width: "100%",
    height: "100vh",
    overflow: "hidden",
    margin: 0,
    padding: 0,
    fontFamily: "sans-serif",
  };

  const backgroundStyle: React.CSSProperties = {
    position: "absolute",
    top: 0,
    left: 0,
    width: "100%",
    height: "100%",
    backgroundImage: `url("https://images-ext-1.discordapp.net/external/3y6aXITKlbdzzA78bFGisPdxLGbN_n9jlkgm6Jmg7mo/https/www.gtp.gr/MGfiles/location/image29873%5B8707%5D.JPG?format=webp&width=1043&height=695")`,
    backgroundSize: "cover",
    backgroundPosition: "center",
    filter: "blur(8px)",
    zIndex: 1,
  };

  const overlayStyle: React.CSSProperties = {
    position: "absolute",
    top: 0,
    left: 0,
    width: "100%",
    height: "100%",
    backgroundColor: "rgba(0, 0, 0, 0.4)",
    zIndex: 2,
  };

  const contentStyle: React.CSSProperties = {
    position: "relative",
    zIndex: 3,
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    height: "100%",
    color: "#fff",
  };

  const navStyle: React.CSSProperties = {
    width: "100%",
    backgroundColor: "rgba(0, 0, 0, 0.7)",
    padding: "1rem",
    position: "absolute",
    top: 0,
    left: 0,
    zIndex: 4,
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
  };

  const buttonStyle: React.CSSProperties = {
    backgroundColor: "#00B0FF",
    color: "#fff",
    padding: "0.75rem 1.5rem",
    border: "none",
    borderRadius: "4px",
    fontSize: "1rem",
    cursor: "pointer",
  };

  const clearDbButtonStyle: React.CSSProperties = {
    backgroundColor: "#ff4444",
    color: "#fff",
    padding: "0.75rem 1.5rem",
    border: "none",
    borderRadius: "4px",
    fontSize: "1rem",
    cursor: "pointer",
    marginTop: "1rem",
  };

  const messageStyle: React.CSSProperties = {
    marginTop: "1rem",
    padding: "0.75rem",
    borderRadius: "4px",
    fontWeight: "bold",
    backgroundColor: "rgba(255, 255, 255, 0.2)",
  };

  return (
    <div style={containerStyle}>
      <div style={backgroundStyle}></div>
      <div style={overlayStyle}></div>

      {/* Navigation bar */}
      <nav style={navStyle}>
        <div className="flex space-x-6">
          <Link to="/admin-dashboard" className="text-white hover:text-blue-400">
            Home
          </Link>
          <Link to="/admin-about" className="text-white hover:text-blue-400">
            About
          </Link>
          <Link to="/admin-services" className="text-white hover:text-blue-400">
            Services
          </Link>
          <Link to="/admin-contact" className="text-white hover:text-blue-400">
            Contact
          </Link>
        </div>
        <button onClick={handleLogout} style={buttonStyle}>
          Logout
        </button>
      </nav>

      {/* Περιεχόμενο της σελίδας */}
      <div style={contentStyle}>
        <h2 style={{ fontSize: "2rem", marginBottom: "1rem" }}>
          Καλώς ήρθατε ADMIN στο Dashboard!
        </h2>
        <p>Εδώ μπορείτε να διαχειριστείτε τις λειτουργίες του λογαριασμού σας.</p>

        {/* Κουμπί για άδειασμα βάσης δεδομένων */}
        <button onClick={handleClearDatabase} style={clearDbButtonStyle}>
          🗑 Άδειασμα Βάσης Δεδομένων
        </button>

        {/* Μήνυμα επιβεβαίωσης/αποτυχίας */}
        {message && <p style={messageStyle}>{message}</p>}
      </div>
    </div>
  );
};

export default AdminDashboard;
