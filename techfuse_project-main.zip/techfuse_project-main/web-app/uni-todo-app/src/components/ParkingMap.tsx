import React, { useState, useEffect } from "react";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import MarkerClusterGroup from "react-leaflet-markercluster";
import L from "leaflet";
import iconUrl from "leaflet/dist/images/marker-icon.png";
import iconShadow from "leaflet/dist/images/marker-shadow.png";
import "leaflet/dist/leaflet.css";
import "leaflet.markercluster/dist/MarkerCluster.css";
import "leaflet.markercluster/dist/MarkerCluster.Default.css";
import { Link, useNavigate } from "react-router-dom";

// Fix default marker icons for Leaflet
let DefaultIcon = L.icon({
  iconUrl,
  shadowUrl: iconShadow,
  iconAnchor: [12, 40],
  popupAnchor: [1, -34],
  iconSize: [25, 41],
  shadowSize: [41, 41],
});
L.Marker.prototype.options.icon = DefaultIcon;

interface ParkingSpot {
  id: number;
  spotNumber: number;
  latitude: number;
  longitude: number;
  available: boolean;
}

const ZONE_ID = 1; // Παράδειγμα: μόνο μία ζώνη

// URLs για τα API endpoints
const SPOTS_URL = (zoneId: number) => `http://localhost:7046/api/parking/spots/zone/${zoneId}`;
const USER_INFO_URL = "http://localhost:7046/api/auth/me";


const ParkingMap: React.FC = () => {
  const [parkingSpots, setParkingSpots] = useState<ParkingSpot[]>([]);
  const [userSpot, setUserSpot] = useState<number | null>(null);
  const navigate = useNavigate();


    const backgroundStyle: React.CSSProperties = {
        position: "absolute",
        top: 0,
        left: 0,
        width: "100%",
        height: "100%",
        backgroundImage: `url("https://images-ext-1.discordapp.net/external/3y6aXITKlbdzzA78bFGisPdxLGbN_n9jlkgm6Jmg7mo/https/www.gtp.gr/MGfiles/location/image29873%5B8707%5D.JPG?format=webp&width=1043&height=695")`,
        backgroundSize: "cover",
        backgroundPosition: "center",
        filter: "blur(8px)",
        zIndex: 1,
      };

    const overlayStyle: React.CSSProperties = {
          position: "absolute",
          top: 0,
          left: 0,
          width: "100%",
          height: "100%",
          backgroundColor: "rgba(0, 0, 0, 0.4)",
          zIndex: 2,
        };
  // Φόρτωση parking spots για τη ζώνη
  const loadSpots = () => {
    fetch(SPOTS_URL(ZONE_ID), { credentials: "include" })
      .then((res) => res.json())
      .then((data: ParkingSpot[]) => {
        if (Array.isArray(data)) {
          setParkingSpots(data);
        }
      })
      .catch((err) => console.error("Error fetching parking spots:", err));
  };

  // Φόρτωση στοιχείων χρήστη (selectedSpot)
  const loadUserSpot = () => {
    fetch(USER_INFO_URL, { credentials: "include" })
      .then((res) => res.json())
      .then((data) => {
        if (data.selectedSpot) {
          setUserSpot(data.selectedSpot.id);
        } else {
          setUserSpot(null);
        }
      })
      .catch((err) => console.error("Error fetching user info:", err));
  };

  // Αρχική φόρτωση δεδομένων
  useEffect(() => {
    loadSpots();
    loadUserSpot();
  }, []);

  // Ανάκτηση δεδομένων ξανά όταν το παράθυρο αποκτά focus
  useEffect(() => {
    const handleFocus = () => {
      loadUserSpot();
      loadSpots();
    };
    window.addEventListener("focus", handleFocus);
    return () => {
      window.removeEventListener("focus", handleFocus);
    };
  }, []);

  // Reserve (Select) μία θέση
  const handleReserveSpot = (spotId: number) => {
    if (userSpot) {
      alert("Έχετε ήδη επιλεγμένη θέση! Αποδεσμεύστε την πρώτα.");
      return;
    }
    fetch(`http://localhost:7046/api/parking/spots/${spotId}/reserve`, {
      method: "POST",
      credentials: "include",
    })
      .then((res) => res.text())
      .then((message) => {
        alert(`✅ ${message}`);
        setUserSpot(spotId);
        loadSpots();
      })
      .catch((err) => console.error("Error reserving spot:", err));
  };

  // Release μία θέση
  const handleReleaseSpot = () => {
    if (!userSpot) {
      alert("Δεν έχετε επιλεγμένη θέση.");
      return;
    }
    fetch("http://localhost:7046/api/parking/spots/release", {
      method: "POST",
      credentials: "include",
    })
      .then((res) => res.text())
      .then((message) => {
        alert(`🔓 ${message}`);
        setUserSpot(null);
        loadSpots();
      })
      .catch((err) => console.error("Error releasing spot:", err));
  };

  // Ορισμός χρώματος για το κουμπί Release:
  // Αν ο χρήστης έχει δεσμευμένη θέση, το κουμπί θα είναι γκρι (απενεργοποιημένο),
  // αλλιώς θα είναι κόκκινο (ενεργό) για να τον προτρέψει να κάνει κράτηση.
  const releaseButtonColor = userSpot ? "#dc3545" : "#999" ;

  const backButtonStyle: React.CSSProperties = {
    position: "absolute",
    top: "10px",
    left: "20px",
    background: "rgba(0, 0, 0, 0.6)", // Semi-transparent black
    border: "none",
    color: "#fff",
    fontSize: "1rem",
    fontWeight: "bold",
    cursor: "pointer",
    zIndex: 3,
    padding: "10px 15px",
    borderRadius: "50px", // Round shape
    display: "flex",
    alignItems: "center",
    gap: "8px",
    transition: "background 0.2s ease-in-out",
};

  return (
    
    <div style={{ position: "relative", height: "100vh", width: "100vw" }}>
      {/* Background Layer */}
        <div style={backgroundStyle}></div>
        <div style={overlayStyle}></div>

                  <button onClick={() => navigate("/area1")} style={backButtonStyle}
            onMouseEnter={(e) => (e.currentTarget.style.background = "rgba(0, 0, 0, 0.8)")}
                onMouseLeave={(e) => (e.currentTarget.style.background = "rgba(0, 0, 0, 0.6)")}
                >
                &#8592; Back
            </button>

      {/* Main Content */}
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          height: "100vh",
          position: "relative",
          zIndex: 2,
        }}
      >
        {/* Map Card */}
        <div
          style={{
            backgroundColor: "rgba(255, 255, 255, 0.9)",
            borderRadius: "12px",
            padding: "1.5rem",
            boxShadow: "0 6px 12px rgba(0, 0, 0, 0.3)",
            width: "700px",
            height: "600px",
            maxWidth: "90vw",
            maxHeight: "90vh",
            overflow: "hidden",
            marginTop: "80px",
          }}
        >
          <h3 style={{ marginBottom: "10px", fontSize: "1.2rem" }}>
            Parking Area (Zone {ZONE_ID})
          </h3>
          <MapContainer
            center={[39.6735, 20.8615]}
            zoom={18}
            style={{ height: "500px", width: "100%" }}
          >
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a>'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              maxZoom={20}
            />
            <MarkerClusterGroup chunkedLoading>
              {parkingSpots.map((spot) => (
                <Marker key={spot.id} position={[spot.latitude, spot.longitude]}>
                  <Popup>
                    <p>{`Parking #${spot.spotNumber}`}</p>
                    <button
                    onClick={() => handleReserveSpot(spot.id)}
                    disabled={!spot.available || !!userSpot}
                    style={{
                        background: !!userSpot ? "#aaa" : (spot.available ? "#28a745" : "#aaa"),
                        color: "#fff",
                        border: "none",
                        cursor: spot.available && !userSpot ? "pointer" : "not-allowed",
                        padding: "8px 12px",
                        borderRadius: "5px",
                        marginTop: "5px",
                    }}
                    >
                    {spot.available ? "Select" : "Taken"}
                    </button>
                  </Popup>
                </Marker>
              ))}
            </MarkerClusterGroup>
          </MapContainer>
        </div>

        {/* Release Button */}
        <div
          style={{
            marginTop: "10px",
            padding: "10px",
            backgroundColor: "rgba(255, 255, 255, 0.9)",
            borderRadius: "8px",
            boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)",
            textAlign: "center",
            width: "700px",
            maxWidth: "90vw",
          }}
        >
          {userSpot ? (
            <p>Έχετε επιλεγμένη τη θέση #{userSpot}</p>
          ) : (
            <p>Δεν έχετε επιλεγμένη θέση.</p>
          )}
          <button
            onClick={handleReleaseSpot}
            disabled={!userSpot}
            style={{
              padding: "10px 15px",
              borderRadius: "5px",
              background: releaseButtonColor,
              color: "#fff",
              border: "none",
              cursor: userSpot ? "pointer" : "not-allowed",
              fontSize: "16px",
              marginTop: "5px",
            }}
          >
            Release
          </button>
        </div>
      </div>
    </div>
  );
};

export default ParkingMap;

