// ProtectedRoute.tsx
import React from "react";
import { Navigate, Outlet } from "react-router-dom";

interface ProtectedRouteProps {
    userRole: string | null;
    allowedRoles: string[];
    loading: boolean;
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({
                                                           userRole,
                                                           allowedRoles,
                                                           loading,
                                                       }) => {
    // Αν είμαστε σε φάση φόρτωσης (δεν ξέρουμε ακόμη αν ο χρήστης είναι logged in),
    // δείχνουμε ένα μήνυμα ή spinner και ΔΕΝ κάνουμε redirect.
    if (loading) {
        return <div>Loading...</div>;
    }

    // Αν, μετά τη φόρτωση, userRole είναι null => δεν είσαι συνδεδεμένος
    if (!userRole) {
        return <Navigate to="/" />;
    }

    // Αν ο ρόλος σου δεν είναι στους allowedRoles
    if (!allowedRoles.includes(userRole)) {
        return <Navigate to="/" />;
    }

    // Αλλιώς, επιτρέπουμε την πρόσβαση στο child route
    return <Outlet />;
};

export default ProtectedRoute;