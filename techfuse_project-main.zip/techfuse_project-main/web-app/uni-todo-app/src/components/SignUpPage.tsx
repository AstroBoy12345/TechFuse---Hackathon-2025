import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

const SignUpPage: React.FC = () => {
  const [username, setUsername] = useState<string>("");
  const [password, setPassword] = useState<string>("");
  const [email, setEmail] = useState<string>("");
  const [usernameAvailable, setUsernameAvailable] = useState<boolean | null>(null);
  const [emailAvailable, setEmailAvailable] = useState<boolean | null>(null);
  const [usernameError, setUsernameError] = useState<string | null>(null);
  const [emailError, setEmailError] = useState<string | null>(null);
  const navigate = useNavigate();

  const checkUsernameAvailability = async (username: string) => {
    if (username.trim() === "") {
      setUsernameAvailable(null);
      setUsernameError(null);
      return;
    }

    if (username.length < 4) {
      setUsernameAvailable(null);
      setUsernameError("Username must be at least 4 characters long");
      return;
    }

    try {
      const response = await fetch(`http://localhost:7046/api/auth/check-username/${username}`);
      if (!response.ok) {
        console.error("Error: Received non-OK response from server");
        setUsernameAvailable(null);
        return;
      }

      const data = await response.json();
      setUsernameAvailable(!data.exists);
      setUsernameError(null);

      console.log("API response for username:", data);
    } catch (error) {
      console.error("Error checking username:", error);
      setUsernameAvailable(null);
    }
  };

  const checkEmailAvailability = async (email: string) => {
    if (email.trim() === "") {
      setEmailAvailable(null);
      setEmailError(null);
      return;
    }

    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!emailRegex.test(email)) {
      setEmailAvailable(null);
      setEmailError("Invalid email format");
      return;
    }

    try {
      const response = await fetch(`http://localhost:7046/api/auth/check-email/${email}`);
      if (!response.ok) {
        console.error("Error: Received non-OK response from server");
        setEmailAvailable(null);
        return;
      }

      const data = await response.json();
      setEmailAvailable(!data.exists);
      setEmailError(null);
    } catch (error) {
      console.error("Error checking email:", error);
      setEmailAvailable(null);
    }
  };

  useEffect(() => {
    if (username.trim() === "") {
      setUsernameAvailable(null);
      setUsernameError(null);
      return;
    }
    const timeoutId = setTimeout(() => checkUsernameAvailability(username), 500);
    return () => clearTimeout(timeoutId);
  }, [username]);

  useEffect(() => {
    if (email.trim() === "") {
      setEmailAvailable(null);
      setEmailError(null);
      return;
    }
    const timeoutId = setTimeout(() => checkEmailAvailability(email), 500);
    return () => clearTimeout(timeoutId);
  }, [email]);

  const handleSignUp = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    if (username.length < 4) {
      alert("Username must be at least 4 characters long!");
      return;
    }
    if (usernameAvailable === false) {
      alert("Username already exists!");
      return;
    }
    if (emailAvailable === false) {
      alert("Email already exists!");
      return;
    }

    const response = await fetch("http://localhost:7046/api/auth/signup", {
      method: "POST",
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ username, password, email }),
    });

    if (response.ok) {
      alert("SignUp successful!");
      window.location.href = "/login";
    } else {
      const errorMessage = await response.text();
      alert(errorMessage);
    }
  };

  const containerStyle: React.CSSProperties = {
    position: "relative",
    width: "100%",
    height: "100vh",
    overflow: "hidden",
    margin: 0,
    padding: 0,
    fontFamily: "sans-serif",
  };

  const backgroundStyle: React.CSSProperties = {
    position: "absolute",
    top: 0,
    left: 0,
    width: "100%",
    height: "100%",
    backgroundImage: `url("https://images-ext-1.discordapp.net/external/3y6aXITKlbdzzA78bFGisPdxLGbN_n9jlkgm6Jmg7mo/https/www.gtp.gr/MGfiles/location/image29873%5B8707%5D.JPG?format=webp&width=1043&height=695")`,
    backgroundSize: "cover",
    backgroundPosition: "center",
    filter: "blur(8px)",
    zIndex: 1,
  };

  const overlayStyle: React.CSSProperties = {
    position: "absolute",
    top: 0,
    left: 0,
    width: "100%",
    height: "100%",
    backgroundColor: "rgba(0, 0, 0, 0.4)",
    zIndex: 2,
  };

  const contentStyle: React.CSSProperties = {
    position: "relative",
    zIndex: 3,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    height: "100%",
  };

  const cardStyle: React.CSSProperties = {
    backgroundColor: "#fff",
    borderRadius: "8px",
    boxShadow: "0 8px 16px rgba(0,0,0,0.2)",
    padding: "2rem",
    maxWidth: "400px",
    width: "100%",
  };

  const titleStyle: React.CSSProperties = {
    textAlign: "center",
    marginBottom: "1.5rem",
    color: "#333",
    fontSize: "1.5rem",
    fontWeight: 600,
  };

  const inputStyle: React.CSSProperties = {
    width: "100%",
    padding: "0.75rem",
    marginBottom: "1rem",
    border: "1px solid #ccc",
    borderRadius: "4px",
    fontSize: "1rem",
  };

  const buttonStyle: React.CSSProperties = {
    width: "100%",
    padding: "0.75rem",
    border: "none",
    borderRadius: "4px",
    backgroundColor: "#00B0FF",
    color: "#fff",
    fontSize: "1rem",
    cursor: "pointer",
  };

  const linkButtonStyle: React.CSSProperties = {
    marginTop: "1rem",
    backgroundColor: "transparent",
    border: "none",
    color: "#00B0FF",
    fontSize: "1rem",
    cursor: "pointer",
    textDecoration: "underline",
  };

  const errorStyle: React.CSSProperties = {
    color: "red",
    textAlign: "center",
    marginTop: "1rem",
  };

  return (
    <div style={containerStyle}>
      <div style={backgroundStyle}></div>
      <div style={overlayStyle}></div>
      <div style={contentStyle}>
        <div style={cardStyle}>
          <h2 style={titleStyle}>SignUp</h2>
          <form onSubmit={handleSignUp}>
            <input
              style={inputStyle}
              type="text"
              placeholder="Username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
            {username.trim() !== "" && usernameError && (
              <p style={{ color: "red", marginBottom: "0.5rem" }}>{usernameError}</p>
            )}
            {username.trim() !== "" && usernameAvailable !== null && !usernameError && (
              <p style={{ color: usernameAvailable ? "green" : "red", marginBottom: "0.5rem" }}>
                {usernameAvailable ? "✅ Username is available" : "❌ Username already exists"}
              </p>
            )}
            <input
              style={inputStyle}
              type="email"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            {email.trim() !== "" && emailError && (
              <p style={{ color: "red", marginBottom: "0.5rem" }}>{emailError}</p>
            )}
            {email.trim() !== "" && emailAvailable !== null && !emailError && (
              <p style={{ color: emailAvailable ? "green" : "red", marginBottom: "0.5rem" }}>
                {emailAvailable ? "✅ Email is available" : "❌ Email already exists"}
              </p>
            )}
            <input
              style={inputStyle}
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
            <button style={buttonStyle} type="submit">
              SignUp
            </button>
          </form>
          <div style={{ textAlign: "center" }}>
            <button onClick={() => navigate("/login")} style={linkButtonStyle}>
              Already have an account? Log In
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SignUpPage;
