import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

interface LoginPageProps {
  updateUserRole: (role: string) => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ updateUserRole }) => {
  const [username, setUsername] = useState<string>("");
  const [password, setPassword] = useState<string>("");
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    try {
      const response = await fetch("http://localhost:7046/api/auth/login", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({ username, password }),
        redirect: "manual",
      });

      if (response.ok) {
        fetchUserRole();
      } else {
        setError("Invalid credentials");
      }
    } catch (error) {
      console.error("Login error:", error);
      setError("Something went wrong. Please try again.");
    }
  };

  const fetchUserRole = async () => {
    try {
      const response = await fetch("http://localhost:7046/api/auth/me", {
        method: "GET",
        credentials: "include",
      });

      if (response.ok) {
        const data = await response.json();
        updateUserRole(data.role);

        if (data.role === "USER") {
          navigate("/dashboard");
        } else if (data.role === "ADMIN") {
          navigate("/admin-dashboard");
        }
      } else {
        setError("Failed to retrieve user data");
      }
    } catch (error) {
      console.error("Error fetching user role:", error);
      setError("Something went wrong. Please try again.");
    }
  };

  // ========== STYLES ==========
  const containerStyle: React.CSSProperties = {
    position: "relative",
    width: "100%",
    height: "100vh",
    overflow: "hidden",
    margin: 0,
    padding: 0,
    fontFamily: "sans-serif",
  };

  const backgroundStyle: React.CSSProperties = {
    position: "absolute",
    top: 0,
    left: 0,
    width: "100%",
    height: "100%",
    backgroundImage: `url("https://images-ext-1.discordapp.net/external/3y6aXITKlbdzzA78bFGisPdxLGbN_n9jlkgm6Jmg7mo/https/www.gtp.gr/MGfiles/location/image29873%5B8707%5D.JPG?format=webp&width=1043&height=695")`,
    backgroundSize: "cover",
    backgroundPosition: "center",
    filter: "blur(8px)",
    zIndex: 1,
  };

  const overlayStyle: React.CSSProperties = {
    position: "absolute",
    top: 0,
    left: 0,
    width: "100%",
    height: "100%",
    backgroundColor: "rgba(0, 0, 0, 0.4)",
    zIndex: 2,
  };

  const contentStyle: React.CSSProperties = {
    position: "relative",
    zIndex: 3,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    height: "100%",
  };

  const cardStyle: React.CSSProperties = {
    backgroundColor: "#fff",
    borderRadius: "8px",
    boxShadow: "0 8px 16px rgba(0,0,0,0.2)",
    padding: "2rem",
    maxWidth: "400px",
    width: "100%",
  };

  const titleStyle: React.CSSProperties = {
    textAlign: "center",
    marginBottom: "1.5rem",
    color: "#333",
    fontSize: "1.5rem",
    fontWeight: 600,
  };

  const inputStyle: React.CSSProperties = {
    width: "100%",
    padding: "0.75rem",
    marginBottom: "1rem",
    border: "1px solid #ccc",
    borderRadius: "4px",
    fontSize: "1rem",
  };

  const buttonStyle: React.CSSProperties = {
    width: "100%",
    padding: "0.75rem",
    border: "none",
    borderRadius: "4px",
    backgroundColor: "#00B0FF",
    color: "#fff",
    fontSize: "1rem",
    cursor: "pointer",
  };

  const errorStyle: React.CSSProperties = {
    color: "red",
    textAlign: "center",
    marginTop: "1rem",
  };

  const linkButtonStyle: React.CSSProperties = {
    marginTop: "1rem",
    backgroundColor: "transparent",
    border: "none",
    color: "#00B0FF",
    fontSize: "1rem",
    cursor: "pointer",
    textDecoration: "underline",
  };

  // ========== RENDER ==========
  return (
    <div style={containerStyle}>
      <div style={backgroundStyle}></div>
      <div style={overlayStyle}></div>
      <div style={contentStyle}>
        <div style={cardStyle}>
          <h2 style={titleStyle}>ByteForce login</h2>
          <form onSubmit={handleLogin}>
            <input
              style={inputStyle}
              type="text"
              placeholder="Username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
            <input
              style={inputStyle}
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
            <button type="submit" style={buttonStyle}>
              Login
            </button>
          </form>
          {error && <p style={errorStyle}>{error}</p>}
          <div style={{ textAlign: "center" }}>
            <button
              onClick={() => navigate("/signup")}
              style={linkButtonStyle}
            >
              No account? Sign Up
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
