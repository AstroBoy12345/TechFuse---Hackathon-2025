#include "Recruiter.h"

void Recruiter::Update()
{
	std::cout << "Recruiter " << GetName() << " got notification" << std::endl;
}