#include "Engineer.h"

void Engineer::Update()
{
	std::cout << "Engineer " << GetName() << " got notification" << std::endl;
}