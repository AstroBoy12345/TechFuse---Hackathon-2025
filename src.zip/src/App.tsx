import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import { useState, useEffect } from "react";
import HomePage from "./components/HomePage";
import LoginPage from "./components/LoginPage";
import SignUpPage from "./components/SignUpPage";
import ProtectedRoute from "./components/ProtectedRoute";

function App() {
    const [userRole, setUserRole] = useState<string | null>(null);

    useEffect(() => {
        const fetchUserRole = async () => {
            try {
                const response = await fetch("http://localhost:7046/api/auth/me", {
                    method: "GET",
                    credentials: "include", // ✅ Χρησιμοποιεί το JSESSIONID
                });

                if (response.ok) {
                    const data = await response.json();
                    setUserRole(data.role);
                } else {
                    setUserRole(null);
                }
            } catch (error) {
                console.error("Error fetching user role:", error);
                setUserRole(null);
            }
        };

        fetchUserRole();
    }, []);

    return (
        <Router>
            <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/login" element={<LoginPage />} />
                <Route path="/signup" element={<SignUpPage />} />

                <Route element={<ProtectedRoute userRole={userRole} allowedRoles={["USER"]} />}>
                    <Route path="/dashboard"/>
                </Route>

                <Route element={<ProtectedRoute userRole={userRole} allowedRoles={["ADMIN"]} />}>
                    <Route path="/admin-dashboard"/>
                </Route>
            </Routes>
        </Router>
    );
}

export default App;

