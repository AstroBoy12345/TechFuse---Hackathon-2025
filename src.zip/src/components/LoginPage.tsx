import { useState } from "react";
import { useNavigate } from "react-router-dom";

const LoginPage: React.FC = () => {
    const [username, setUsername] = useState<string>("");
    const [password, setPassword] = useState<string>("");
    const [error, setError] = useState<string | null>(null);
    const navigate = useNavigate(); // ✅ Για μεταφορά σε άλλη σελίδα

    const handleLogin = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();

        try {
            const response = await fetch("http://localhost:7046/api/auth/login", {
                method: "POST",
                credentials: "include",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: new URLSearchParams({ username, password }),
                redirect: "manual" // ✅ Δεν ακολουθεί αυτόματα redirect από backend
            });

            console.log("response:", response);
            console.log("status:", response.status);
            console.log("ok:", response.ok);
            console.log("redirected:", response.redirected);
            console.log("url:", response.url);

            if (response.ok) {
                console.log("Login successful, fetching user role...");
                fetchUserRole();
            } else {
                setError("Invalid credentials");
            }
        } catch (error) {
            console.error("Login error:", error);
            setError("Something went wrong. Please try again.");
        }
    };

    const fetchUserRole = async () => {
        try {
            const response = await fetch("http://localhost:7046/api/auth/me", {
                method: "GET",
                credentials: "include" // ✅ Χρησιμοποιούμε το session cookie
            });

            if (response.ok) {
                const data = await response.json();
                console.log("User role:", data.role);

                // ✅ Αν ο χρήστης είναι USER -> Πήγαινε στο Dashboard
                    if (data.role === "USER") {
                        navigate("/dashboard");
                    }
                    // ✅ Αν ο χρήστης είναι ADMIN -> Πήγαινε στο Admin Dashboard
                    else if (data.role === "ADMIN") {
                        navigate("/admin-dashboard");
                    }
            } else {
                setError("Failed to retrieve user data");
            }
        } catch (error) {
            console.error("Error fetching user role:", error);
            setError("Something went wrong. Please try again.");
        }
    };

    return (
        <div>
            <h2>Login</h2>
            <form onSubmit={handleLogin}>
                <input
                    type="text"
                    placeholder="Username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    required
                />
                <input
                    type="password"
                    placeholder="Password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                />
                <button type="submit">Login</button>
            </form>
            {error && <p style={{ color: "red" }}>{error}</p>}
        </div>
    );
};

export default LoginPage;
