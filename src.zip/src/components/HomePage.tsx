import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";

// ✅ Ορισμός του τύπου για το state isAuthenticated
type AuthState = boolean | null;

const HomePage: React.FC = () => {
    const [isAuthenticated, setIsAuthenticated] = useState<AuthState>(null);
    const navigate = useNavigate();

    useEffect(() => {
        fetch("http://localhost:7064/api/auth/user", {
            method: "GET",
            credentials: "include", // ✅ Στέλνει το session cookie
        })
        .then((response) => {
            if (response.ok) {
                setIsAuthenticated(true);
            } else {
                setIsAuthenticated(false);
            }
        })
        .catch(() => setIsAuthenticated(false));
    }, []);

    const handleGoToDashboard = () => {
        navigate("/dashboard");
    };

    function setIsOpen(arg0: boolean): void {
        throw new Error("Function not implemented.");
    }

    return (
        <nav className="bg-gray-800 p-4">
          <div className="container mx-auto flex justify-between items-center">
            {/* Logo */}
            <Link to="/" className="text-white text-xl font-bold">
              MySite
            </Link>
              <li>
                <Link to="/" className="hover:text-gray-400">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/about" className="hover:text-gray-400">
                  About
                </Link>
              </li>
              <li>
                <Link to="/services" className="hover:text-gray-400">
                  Services
                </Link>
              </li>
              <li>
                <Link to="/contact" className="hover:text-gray-400">
                  Contact
                </Link>
              </li>
              <li>
                <Link to="/login" className="hover:text-gray-400">
                  Login
                </Link>
              </li>
              <li>
                <Link to="/signup" className="hover:text-gray-400">
                  SignUp
                </Link>
              </li>
           
          </div>
        </nav>
      );
    };

export default HomePage;