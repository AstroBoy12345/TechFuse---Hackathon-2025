import { Navigate, Outlet } from "react-router-dom";

const ProtectedRoute = ({ userRole, allowedRoles }: { userRole: string | null; allowedRoles: string[] }) => {
    if (!userRole) {
        return <Navigate to="/" replace />; // 🚫 Αν δεν είναι authenticated, επιστρέφει στο login
    }

    if (!allowedRoles.includes(userRole)) {
        return <Navigate to="/" replace />; // 🚫 Αν δεν έχει το σωστό ρόλο, επιστρέφει στο login
    }

    return <Outlet />;
};

export default ProtectedRoute;