import { useState, useEffect } from "react";

const SignUpPage: React.FC = () => {
    const [username, setUsername] = useState<string>("");
    const [password, setPassword] = useState<string>("");
    const [email, setEmail] = useState<string>("");
    const [usernameAvailable, setUsernameAvailable] = useState<boolean | null>(null);
    const [emailAvailable, setEmailAvailable] = useState<boolean | null>(null);
    const [usernameError, setUsernameError] = useState<string | null>(null);
    const [emailError, setEmailError] = useState<string | null>(null);

    const checkUsernameAvailability = async (username: string) => {
        if (username.trim() === "") {
            setUsernameAvailable(null);
            setUsernameError(null);
            return;
        }

        if (username.length < 4) {
            setUsernameAvailable(null);
            setUsernameError("Username must be at least 4 characters long");
            return;
        }

        try {
            const response = await fetch(`http://localhost:7046/api/auth/check-username/${username}`);
            if (!response.ok) {
                console.error("Error: Received non-OK response from server");
                setUsernameAvailable(null);
                return;
            }

            const data = await response.json();
            setUsernameAvailable(!data.exists);
            setUsernameError(null);
        } catch (error) {
            console.error("Error checking username:", error);
            setUsernameAvailable(null);
        }
    };

    const checkEmailAvailability = async (email: string) => {
        if (email.trim() === "") {
            setEmailAvailable(null);
            setEmailError(null);
            return;
        }

        // ✅ Βασικός έλεγχος email format
        const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        if (!emailRegex.test(email)) {
            setEmailAvailable(null);
            setEmailError("Invalid email format");
            return;
        }

        try {
            const response = await fetch(`http://localhost:7046/api/auth/check-email/${email}`);
            if (!response.ok) {
                console.error("Error: Received non-OK response from server");
                setEmailAvailable(null);
                return;
            }

            const data = await response.json();
            setEmailAvailable(!data.exists);
            setEmailError(null);
        } catch (error) {
            console.error("Error checking email:", error);
            setEmailAvailable(null);
        }
    };

    useEffect(() => {
        if (username.trim() === "") {
            setUsernameAvailable(null);
            setUsernameError(null);
            return;
        }

        const timeoutId = setTimeout(() => checkUsernameAvailability(username), 500);
        return () => clearTimeout(timeoutId);
    }, [username]);

    useEffect(() => {
        if (email.trim() === "") {
            setEmailAvailable(null);
            setEmailError(null);
            return;
        }

        const timeoutId = setTimeout(() => checkEmailAvailability(email), 500);
        return () => clearTimeout(timeoutId);
    }, [email]);

    const handleSignUp = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();

        if (username.length < 4) {
            alert("Username must be at least 4 characters long!");
            return;
        }

        if (usernameAvailable === false) {
            alert("Username already exists!");
            return;
        }

        if (emailAvailable === false) {
            alert("Email already exists!");
            return;
        }

        const response = await fetch("http://localhost:7046/api/auth/signup", {
            method: "POST",
            credentials: "include",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({ username, password, email }),
        });

        if (response.ok) {
            alert("SignUp successful!");
            window.location.href = "/login";
        } else {
            const errorMessage = await response.text();
            alert(errorMessage);
        }
    };

    return (
        <div>
            <h2>SignUp</h2>
            <form onSubmit={handleSignUp}>
                <input
                    type="text"
                    placeholder="Username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    required
                />
                {username.trim() !== "" && usernameError && <p style={{ color: "red" }}>{usernameError}</p>}
                {username.trim() !== "" && usernameAvailable !== null && !usernameError && (
                    <p style={{ color: usernameAvailable ? "green" : "red" }}>
                        {usernameAvailable ? "✅ Username is available" : "❌ Username already exists"}
                    </p>
                )}

                <input
                    type="email"
                    placeholder="Email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                />
                {email.trim() !== "" && emailError && <p style={{ color: "red" }}>{emailError}</p>}
                {email.trim() !== "" && emailAvailable !== null && !emailError && (
                    <p style={{ color: emailAvailable ? "green" : "red" }}>
                        {emailAvailable ? "✅ Email is available" : "❌ Email already exists"}
                    </p>
                )}

                <input
                    type="password"
                    placeholder="Password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                />
                <button type="submit" disabled={username.length < 4 || usernameAvailable === false || emailAvailable === false}>
                    Submit
                </button>
            </form>
        </div>
    );
};

export default SignUpPage;
