export const env = {
  webApi: "https://localhost:7046",
  springApi: "http://localhost:7046"
};
